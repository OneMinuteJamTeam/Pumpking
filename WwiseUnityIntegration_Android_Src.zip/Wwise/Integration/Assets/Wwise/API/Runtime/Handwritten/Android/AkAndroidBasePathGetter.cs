﻿#if UNITY_ANDROID && !UNITY_EDITOR
public partial class AkBasePathGetter
{
	static string DefaultPlatformName = "Android";
}
#endif